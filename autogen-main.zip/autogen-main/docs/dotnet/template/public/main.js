export default {
    iconLinks: [
      {
        icon: 'github',
        href: 'https://github.com/microsoft/autogen',
        title: 'GitHub'
      }
    ]
  }
// Copyright (c) Microsoft Corporation. All rights reserved.
// CountUpdate.cs

#region snippet_CountUpdate
namespace GettingStartedSample;

public class CountUpdate
{
    public int NewCount { get; set; }
}
#endregion

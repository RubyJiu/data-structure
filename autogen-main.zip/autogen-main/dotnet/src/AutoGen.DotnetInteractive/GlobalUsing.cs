// Copyright (c) Microsoft Corporation. All rights reserved.
// GlobalUsing.cs

global using AutoGen.Core;

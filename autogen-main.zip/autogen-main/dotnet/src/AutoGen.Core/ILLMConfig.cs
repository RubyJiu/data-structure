// Copyright (c) Microsoft Corporation. All rights reserved.
// ILLMConfig.cs

namespace AutoGen.Core;

public interface ILLMConfig
{
}
